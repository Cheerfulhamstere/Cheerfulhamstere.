document.addEventListener('DOMContentLoaded', () => {
  // Создание кибер-границ
  const createBorder = (side) => {
    const border = document.createElement('div');
    border.className = 'cyber-border';
    Object.assign(border.style, {
            [side]: '0',
      width: side === 'top' || side === 'bottom' ? '100vw' : '2px',
      height: side === 'top' || side === 'bottom' ? '2px' : '100vh'
    });
    document.body.appendChild(border);
  };

    ['top', 'right', 'bottom', 'left'].forEach(createBorder);

  // Параллакс-эффект
  document.addEventListener('mousemove', (e) => {
    const x = (e.clientX / window.innerWidth - 0.5) * 20;
    const y = (e.clientY / window.innerHeight - 0.5) * 20;
    document.querySelector('.gallery').style.transform =
      `perspective(1000px) rotateX(${y}deg) rotateY(${x}deg)`;
  });

  // Анимация карточек при прокрутке
  const cards = document.querySelectorAll('.nft-card');
  const animateCards = () => {
    cards.forEach(card => {
      const rect = card.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.8) {
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }
    });
  };
  window.addEventListener('scroll', animateCards);
  animateCards();
});